-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2021 at 08:56 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `daraz-clone`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_cart`
--

CREATE TABLE `add_cart` (
  `cart_id` int(50) NOT NULL,
  `user_id` int(50) DEFAULT NULL,
  `product_id` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_cart`
--

INSERT INTO `add_cart` (`cart_id`, `user_id`, `product_id`) VALUES
(7, 24, 22),
(11, 22, 39),
(12, 22, 38),
(13, 22, 28),
(14, 22, 30),
(22, 22, 41),
(23, 22, 22),
(24, 22, 25);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `com_logo` varchar(100) DEFAULT NULL,
  `com_name` varchar(100) NOT NULL,
  `com_email` varchar(60) NOT NULL,
  `com_phone` varchar(15) DEFAULT NULL,
  `com_address` varchar(255) DEFAULT NULL,
  `cur_format` varchar(10) NOT NULL,
  `admin_role` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `username`, `password`, `com_logo`, `com_name`, `com_email`, `com_phone`, `com_address`, `cur_format`, `admin_role`) VALUES
(1, 'admin', 'admin', '$2y$10$pAXCjt7KuBoMmVGB3miwbOdq/hgQ/zhKHNJ0OgnG2oj3J8r7rmbmO', NULL, 'Random', 'Random@gmail.com', '9203030033', '#dd4df34', 'Rs', 1);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_title` text NOT NULL,
  `brand_cat` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`, `brand_cat`) VALUES
(15, 'NIKE', 25),
(16, 'NIKE', 24),
(17, 'Apple', 16),
(18, 'Lenovo', 16),
(19, 'Fendi', 24),
(20, 'Cream', 21);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL,
  `products` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `products`) VALUES
(16, 'Electronics', 0),
(18, 'Sports', 0),
(21, 'Home &amp; Lifesytle', 0),
(22, 'Health &amp; Beauty', 0),
(24, 'Men&#039;s Fashion', 0),
(25, 'Women&#039;s Fashion', 0),
(26, 'Groceries &amp; Pets', 0);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `s_no` int(11) NOT NULL,
  `site_name` varchar(100) NOT NULL,
  `site_title` varchar(100) DEFAULT NULL,
  `site_logo` varchar(100) NOT NULL,
  `site_desc` varchar(255) DEFAULT NULL,
  `footer_text` varchar(100) NOT NULL,
  `currency_format` varchar(20) NOT NULL,
  `contact_phone` varchar(15) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `contact_address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`s_no`, `site_name`, `site_title`, `site_logo`, `site_desc`, `footer_text`, `currency_format`, `contact_phone`, `contact_email`, `contact_address`) VALUES
(1, 'Daraz Store', 'Online Shopping Project for Mobiles, Clothes, Electronics and many more....', '1632486145-logo.png', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur, perspiciatis quia repudiandae sapiente sed sunt.', 'Copyright 2020', 'Rs.', '9876541230', 'email@email1.com', '#123, Lorem Ipsum');

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_id` int(11) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `product_qty` varchar(100) NOT NULL,
  `total_amount` varchar(10) NOT NULL,
  `product_user` int(11) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `pay_req_id` varchar(100) DEFAULT NULL,
  `confirm` tinyint(4) NOT NULL DEFAULT 0,
  `delivery` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `item_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `txn_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `payment_gross` float(10,2) NOT NULL,
  `currency_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `item_number`, `txn_id`, `payment_gross`, `currency_code`, `payment_status`) VALUES
(1, '11', 'd388939cdaca4087acca75574a34b035', 759.00, '', 'credit'),
(2, '12', '4e2738d7eade4f57b5fd32434239d35f', 299.00, '', 'credit'),
(3, '12', 'd7a5b179cd07480782fc2d21edec7031', 299.00, '', 'credit'),
(4, '12', 'a0f61b1acd6b444ba5856cc4387e7710', 299.00, '', 'pending'),
(5, '12', '0e2fdf1541994d338c676201097d2481', 598.00, '', 'credit'),
(6, '12', '8b0791e3eb764e45b497b0f0c401d9d6', 299.00, '', 'credit'),
(7, '12', '92c9c474ae864d01b81f7e2f4d3a098e', 299.00, '', 'credit'),
(8, '11', '6863fbdf68be45d5a77aa01774a80885', 759.00, '', 'credit'),
(9, '11', 'ee7d6cea937c4f06b6e5e1fffe47b778', 759.00, '', 'credit'),
(10, '12', 'f7ce91d5964c462fa3972f6cb5373d4a', 299.00, '', 'credit'),
(11, '11', '939d866425ef479c84e276e664ce5a31', 1518.00, '', 'credit'),
(12, '10,11,12,', 'df952fa6bacd4f389de80b1080ed3871', 1342.00, '', 'credit'),
(13, '4,12,', 'd19818d2ba3543ffa03a79a7eb64901b', 94279.00, '', 'credit'),
(14, '11,12,', '2c648ec714914c18b447309d691b7eef', 1058.00, '', 'credit'),
(15, '11,12,', '700bf310ca4a4697b59184f61309275a', 1058.00, '', 'credit'),
(16, '11,12,', '639ccfba60cd41eeba02ba5ff1849249', 1058.00, '', 'credit'),
(17, '11,12,', '792c6616026948e48a2fcc07eb35c158', 1058.00, '', 'credit'),
(18, '11,12,', '153427404661463f83a5e8bd080a95e9', 1058.00, '', 'credit'),
(19, '11,12,', '37473185580340ab8c54d102204c7bf9', 1058.00, '', 'credit'),
(20, '11,12,', '2bb8d2ccf3544d0089d211abf4d55e36', 1058.00, '', 'credit'),
(21, '12,13,', '63148f0e7b7043f5a5e470a9ac1d3dde', 1532.00, '', 'credit'),
(22, '12,', '3c209af45445486c8aefb6cfb55dcbb7', 299.00, '', 'credit');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_sub_cat` int(11) DEFAULT NULL,
  `product_brand` int(100) DEFAULT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_desc` text NOT NULL,
  `featured_image` text NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1,
  `product_keywords` text DEFAULT NULL,
  `product_views` int(11) DEFAULT 0,
  `product_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `product_cat`, `product_sub_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `featured_image`, `qty`, `product_keywords`, `product_views`, `product_status`) VALUES
(20, '1632544437', 16, 21, 17, 'Nokia C1 -5.45 Display 1GB RAM 16GB ROM', '20000', '&lt;ol&gt;&lt;li&gt;Battery Time 24hr&lt;/li&gt;&lt;li&gt;Processor 2.3GH&lt;/li&gt;&lt;li&gt;High resolution&lt;/li&gt;&lt;/ol&gt;', '1632544437-mobile1.jpg', 5, '', 0, 1),
(21, '1632545362', 16, 21, 18, 'Realme 7 Pro - 6.4&quot; Super AMOLED Display - 8GB RAM 128GB ROM - 64MP Sony Quad Camera - 65W Super Dart Charge', '28000', '&lt;ul&gt;&lt;li&gt;8GB RAM&lt;/li&gt;&lt;li&gt;128GB ROM&lt;/li&gt;&lt;li&gt;3GH processor&lt;/li&gt;&lt;li&gt;Long Battery Time&lt;/li&gt;&lt;li&gt;And much more other features to explore&lt;/li&gt;&lt;/ul&gt;', '1632545362-mobile2.jpg', 8, '', 0, 1),
(22, '1632545520', 16, 21, 18, 'Nokia 3.4 - 4GB RAM - 64GB ROM - Snapdragon 460 - 4000 mAh Battery', '30000', '&lt;ol&gt;&lt;li&gt;Best Smart phone ever you have used&lt;/li&gt;&lt;li&gt;Some features that no other any phone have&lt;/li&gt;&lt;li&gt;And here some description &lt;strong&gt;goes&lt;/strong&gt;&lt;/li&gt;&lt;/ol&gt;', '1632545520-mobile3.jpg', 2, '', 0, 1),
(23, '1632545701', 16, 52, 18, 'Lenovo Ideapad 330 - Intel Celeron N4000 - 15.6 HD Laptop - 4GB RAM - 1TB HDD - DOS - 1 Year Lenovo Direct Official Warranty', '50000', '&lt;p&gt;Lenovo Ideapad 330 - Intel Celeron N4000 - 15.6 HD Laptop - &lt;strong&gt;4GB &lt;/strong&gt;RAM - &lt;strong&gt;1TB &lt;/strong&gt;HDD - DOS - 1 Year Lenovo Direct Official Warranty.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Very Powerful processor&lt;/li&gt;&lt;/ul&gt;', '1632545701-laptop1.jpg', 10, '', 0, 1),
(24, '1632545900', 16, 52, 0, ' Insprion 15 5502 - |i5-1135G7|8GB|256GB SSD|802.11ac 2x2 WiFi + BT|UBUNTU|Intel&reg; Iris&reg; Xe Graphics| BACKLIT KEYBOARD + FPR|FHD WVA Panel|Essential Backpack|MCAFEE|2CIS+1EBS', '60000', '&lt;p&gt;&lt;br&gt;Insprion 15 5502 - |i5-1135G7|8GB|256GB SSD|802.11ac 2x2 WiFi + BT|UBUNTU|Intel&reg; Iris&reg; Xe Graphics| BACKLIT KEYBOARD + FPR|FHD WVA Panel|Essential Backpack|MCAFEE|2CIS+1EBS.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Consider best among the &lt;i&gt;contemporaries&lt;/i&gt;&lt;/li&gt;&lt;/ul&gt;', '1632545900-laptop2.jpg', 2, '', 0, 1),
(25, '1632546095', 16, 23, 17, 'Core i5 3470 Gaming PC - Processor Upto 3.60 GHz - 3rd Generation - 8GB RAM DDR3 - 500GB HDD - 128 GB SSD', '45000', '&lt;p&gt;Core i5 3470 Gaming PC - Processor Upto &lt;strong&gt;3.60 &lt;/strong&gt;GHz - 3rd &quot;Generation&amp;nbsp;&quot;- 8GB RAM DDR3 - 500GB HDD - &lt;strong&gt;128 &lt;/strong&gt;GB SSD.&lt;/p&gt;&lt;ol&gt;&lt;li&gt;the best one&lt;/li&gt;&lt;/ol&gt;', '1632546095-computer1.jpg', 34, '', 0, 1),
(26, '1632546189', 16, 23, 0, 'OptiPlex 790 Gaming PC Core i5-2400 Upto 3.4GHz 8GB DDR3 RAM - 500GB HD- LED Monitor 19 Windows 10 64-bit', '37000', '&lt;p&gt;OptiPlex 790 Gaming PC Core i5-2400 Upto 3.4GHz 8GB DDR3 RAM - 500GB HD- LED Monitor 19 Windows 10 64-bit&lt;/p&gt;', '1632546189-computer2.jpg', 3, '', 0, 1),
(27, '1632546312', 25, 29, 0, 'Wedding Bazu Band Set For Dulha Dulhan ( 1 Band )', '200', '&lt;p&gt;Wedding Bazu Band Set For Dulha Dulhan ( 1 Band ).&lt;/p&gt;&lt;ol&gt;&lt;li&gt;Something very special about this one&lt;/li&gt;&lt;/ol&gt;', '1632546312-women1.jpg', 45, '', 0, 1),
(28, '1632546386', 25, 29, 0, 'kashmiri Baby Cap Handmade Be Hijab', '120', '&lt;p&gt;kashmiri Baby Cap Handmade Be &lt;i&gt;Hijabkashmiri &lt;/i&gt;Baby Cap Handmade Be Hijabkashmiri Baby Cap Handmade Be &lt;strong&gt;Hijab&lt;/strong&gt;&lt;/p&gt;', '1632546386-women2.jpg', 34, '', 0, 1),
(29, '1632546499', 25, 32, 0, 'Ghazi fabric Black Gold print 2piece shirt and trouser fabric new design Trendy party wear 2 piece(gf7766)', '670', '&lt;p&gt;Ghazi fabric Black Gold &lt;i&gt;print &lt;/i&gt;2piece shirt and trouser fabric new design Trendy party wear 2 piece(gf7766) Ghazi fabric Black Gold print 2piece shirt and trouser fabric new design Trendy party wear 2 &lt;strong&gt;piece&lt;/strong&gt;(gf7766)&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Ghazi&amp;nbsp; Ghazi&amp;nbsp;&lt;/li&gt;&lt;/ul&gt;', '1632546499-w_dress1.jpg', 56, '', 0, 1),
(30, '1632546572', 25, 32, 0, 'New Linen Collection Hot Design Top Quality Fabric/Shirt &amp; trouser / Gold print / trendy /Elegant /Traditional /Hot Article', '2000', '&lt;p&gt;New Linen Collection Hot Design Top Quality Fabric/Shirt &amp;amp; trouser / Gold print / trendy /Elegant /Traditional /Hot Article New Linen Collection Hot Design Top Quality Fabric/Shirt &amp;amp; trouser / Gold print / trendy /Elegant /Traditional /Hot Article&lt;/p&gt;', '1632546572-w_dress2.jpg', 66, '', 0, 1),
(31, '1632546751', 25, 31, 0, 'gee&amp;geeuk Kids Ultra soft tights Newborn Lycra Tights Opaque tights Stretchable tights with Control Top for Everyday Use &amp; Everyday Fitness Tights from Newborn to 5 years-Black,Blue,White,Pink,Yellow', '45666', '&lt;p&gt;gee&amp;amp;geeuk Kids Ultra soft tights Newborn Lycra Tights Opaque tights Stretchable tights with Control Top for Everyday Use &amp;amp; Everyday Fitness Tights from Newborn to 5 years-Black,Blue,White,Pink,Yellow gee&amp;amp;geeuk Kids Ultra soft tights Newborn Lycra Tights Opaque tights Stretchable tights with Control Top for Everyday Use &amp;amp; Everyday Fitness Tights from Newborn to 5 years-Black,Blue,White,Pink,Yellow&lt;/p&gt;', '1632546751-women_clothing1.jpg', 34, '', 0, 1),
(32, '1632546872', 24, 25, 16, 'The Vintage Clothing Pack of 5 plain half sleeves T shirts', '500', '&lt;p&gt;The Vintage Clothing Pack of 5 plain half sleeves T shirts .&lt;/p&gt;&lt;ol&gt;&lt;li&gt;The Vintage Clothing Pack of 5 &lt;strong&gt;plain &lt;/strong&gt;half sleeves T shirts&lt;/li&gt;&lt;li&gt;The Vintage Clothing Pack of 5 plain half &lt;i&gt;sleeves &lt;/i&gt;T shirts&lt;/li&gt;&lt;/ol&gt;', '1632546872-men_shirts1.jpg', 324, '', 0, 1),
(33, '1632546989', 24, 25, 0, 'The Shop - Multicolors FREE FIRE T Shirt For Men &amp; Women, Round Neck Half Sleeves T-Shirt - FF-MC1', '500', '&lt;p&gt;The Shop - Multicolors FREE FIRE T Shirt For Men &amp;amp; Women, Round Neck Half Sleeves T-Shirt - FF-MC1&lt;/p&gt;&lt;ol&gt;&lt;li&gt;The Shop - Multicolors FREE FIRE T Shirt For Men &amp;amp; Women, Round Neck Half Sleeves T-Shirt - FF-MC1&lt;/li&gt;&lt;/ol&gt;', '1632546989-men_shirts2.jpg', 234, '', 0, 1),
(34, '1632547113', 24, 27, 0, 'Hinz Men&#039;s Essential Side Stripe Trouser (Pack of 2) Polyester Cotton', '780', '&lt;p&gt;Hinz Men&#039;s Essential Side Stripe Trouser (Pack of 2) Polyester Cotton.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Hinz Men&#039;s Essential Side &lt;strong&gt;Stripe &lt;/strong&gt;Trouser (Pack of 2) Polyester Cotton&lt;/li&gt;&lt;li&gt;Hinz Men&#039;s &lt;strong&gt;Essential &lt;/strong&gt;Side Stripe Trouser (Pack of 2) &lt;i&gt;Polyester &lt;/i&gt;Cotton&lt;/li&gt;&lt;/ul&gt;', '1632547113-men_pants2.jpg', 32, '', 0, 1),
(35, '1632547200', 24, 27, 0, 'AYBEEZ- Interlock Contrast Panelling Trouser For Men', '2343', '&lt;p&gt;AYBEEZ- Interlock Contrast Panelling Trouser For Men.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;AYBEEZ- &lt;i&gt;Interlock &lt;/i&gt;Contrast Panelling Trouser For Men&lt;/li&gt;&lt;li&gt;AYBEEZ- Interlock Contrast &lt;strong&gt;Panelling &lt;/strong&gt;Trouser For Men&lt;/li&gt;&lt;/ul&gt;', '1632547187-men_pants1.jpg', 33, '', 0, 1),
(36, '1632547333', 24, 28, 0, '(MK) Black &amp; Brown - Synthetic Material Sandals for Men', '2333', '&lt;p&gt;(MK) Black &amp;amp; Brown - Synthetic Material Sandals for Men(MK) Black &amp;amp; Brown - Synthetic Material Sandals for Men(MK) Black &amp;amp; Brown - Synthetic Material Sandals for Men(MK) Black &amp;amp; Brown - Synthetic Material Sandals for Men&lt;/p&gt;', '1632547333-men_shoes2.jpg', 12, '', 0, 1),
(37, '1632547384', 25, 30, 0, 'CLOGS CROCS CROCKS SHOES FLIP FLOP FOR MEN IN BLUE BLACK, BROWN COLORS', '1000', '&lt;p&gt;CLOGS CROCS CROCKS SHOES FLIP FLOP FOR MEN IN BLUE BLACK, BROWN COLORSCLOGS CROCS CROCKS SHOES FLIP FLOP FOR MEN IN BLUE BLACK, BROWN COLORS&lt;/p&gt;', '1632547384-men_shoes1.jpg', 4, '', 0, 1),
(38, '1632547528', 18, 48, 0, 'Skipping Rope Adjustable Jumping Rope Fitness Speed Gym Adults Girls Kids Men', '6000', '&lt;p&gt;Skipping Rope Adjustable Jumping Rope Fitness Speed Gym Adults Girls Kids MenSkipping Rope Adjustable Jumping Rope Fitness Speed Gym Adults Girls Kids MenSkipping Rope Adjustable Jumping Rope Fitness Speed Gym Adults Girls Kids MenSkipping Rope Adjustable Jumping Rope Fitness Speed Gym Adults Girls Kids Men&lt;/p&gt;', '1632547528-fitness1.jpg', 34, '', 0, 1),
(39, '1632547631', 18, 48, 0, 'Women Men Body Shaper Sweat Belt Premium Waist Trimmer', '2000', '&lt;p&gt;Women Men Body Shaper Sweat Belt Premium Waist Trimmer Women Men Body Shaper Sweat Belt Premium Waist Trimmer Women Men Body Shaper Sweat Belt Premium Waist Trimmer&lt;/p&gt;', '1632547631-fitness2.jpg', 9, '', 0, 1),
(40, '1632553603', 22, 39, 0, 'Hemani Antiseptic Hand Sanitizer Pouch 400ml', '500', '&lt;ol&gt;&lt;li&gt;Hemani Antiseptic Hand &lt;i&gt;Sanitizer &lt;/i&gt;Pouch 400ml&amp;nbsp;&lt;/li&gt;&lt;li&gt;Hemani Antiseptic Hand Sanitizer &lt;strong&gt;Pouch &lt;/strong&gt;3&lt;/li&gt;&lt;li&gt;Hemani Antiseptic Hand Sanitizer Pouch 400ml&lt;/li&gt;&lt;/ol&gt;', '1632553603-bath_body2.jpg', 23, '', 0, 1),
(41, '1632553726', 22, 39, 0, '1 Pair (2PCS) Heel Pain Anti Crack Silicone Care Set Silicone Sock Heel Crack Protector Pain Relief Heel Socks', '2000', '&lt;ol&gt;&lt;li&gt;1 Pair (2PCS) Heel Pain Anti &lt;strong&gt;Crack &lt;/strong&gt;Silicone Care Set Silicone Sock Heel Crack Protector Pain Relief Heel Socks&lt;/li&gt;&lt;li&gt;1 Pair (2PCS) Heel &lt;i&gt;Pain &lt;/i&gt;Anti Crack Silicone Care Set Silicone Sock Heel Crack Protector Pain Relief Heel Socks&lt;/li&gt;&lt;/ol&gt;', '1632553726-bath_body1.jpg', 67, '', 0, 1),
(42, '1632553873', 21, 47, 0, 'Plastic Cloth Hanging Rope Clothesline - 5 Meters', '4500', '&lt;ul&gt;&lt;li&gt;Plastic Cloth Hanging Rope &lt;strong&gt;Clothesline &lt;/strong&gt;- 5 Meters.&lt;/li&gt;&lt;li&gt;Plastic Cloth Hanging Rope Clothesline - 5 Meters. Plastic Cloth Hanging Rope Clothesline - 5 Meters&lt;/li&gt;&lt;/ul&gt;', '1632553873-laundry_kitchen2.jpg', 45, '', 0, 1),
(43, '1632553989', 21, 47, 0, 'TC Reusable Silicone Magic Washing Gloves with Scrubber, Cleaning Brush Scrubber Gloves Heat Resistant Pair for Cleaning of Kitchen, Dishes, Vegetables and Fruits, Bathroom, Car Wash, Pet Care and Multipurpose', '200', '&lt;p&gt;TC Reusable Silicone Magic Washing Gloves with Scrubber, Cleaning Brush Scrubber Gloves Heat Resistant Pair for Cleaning of Kitchen, Dishes, Vegetables and Fruits, Bathroom, Car Wash, Pet Care and Multipurpose &lt;/p&gt;&lt;ul&gt;&lt;li&gt;NOthing&lt;/li&gt;&lt;li&gt;wwwow&lt;/li&gt;&lt;/ul&gt;', '1632553989-laundry_kitchen1.jpg', 2, '', 0, 1),
(44, '1632554042', 21, 45, 0, 'Jersey Cotton 3 Seater Sofa Cover Stretchable (Standard Size) - Beddys Studio', '100000', '&lt;ul&gt;&lt;li&gt;Jersey Cotton 3 Seater Sofa Cover &lt;i&gt;Stretchable &lt;/i&gt;(Standard Size) - &lt;strong&gt;Beddys &lt;/strong&gt;Studio.&lt;/li&gt;&lt;li&gt;Jersey Cotton 3 Seater Sofa Cover Stretchable (Standard Size)&amp;nbsp;&lt;/li&gt;&lt;/ul&gt;', '1632554042-furniture2.png', 3, '', 0, 1),
(45, '1632554093', 21, 45, 0, 'Jersey Cotton Two 2 Seater Sofa Cover Stretchable (Standard Size) - Beddy&#039;s Studio', '200000', '&lt;ol&gt;&lt;li&gt;Jersey Cotton Two 2 Seater Sofa Cover Stretchable (Standard Size) - Beddy&#039;s Studio&lt;/li&gt;&lt;li&gt;Jersey Cotton Two 2 Seater Sofa Cover Stretchable (Standard Size) - Beddy&#039;s Studio&lt;/li&gt;&lt;/ol&gt;', '1632554093-furniture1.png', 4, '', 0, 1),
(46, '1632554961', 21, 44, 0, 'Waterproof, Anti Dust Mattress Cover/Protector Fitted Sheet', '300000', '&lt;p&gt;Waterproof, Anti Dust Mattress Cover/Protector Fitted SheetWaterproof, Anti Dust Mattress Cover/Protector Fitted SheetWaterproof, Anti Dust Mattress Cover/Protector Fitted SheetWaterproof, Anti Dust Mattress Cover/Protector Fitted Sheet&lt;/p&gt;', '1632554961-bed2.jpg', 2, '', 0, 1),
(47, '1632555017', 21, 44, 19, 'Waterproof Mattress Cover For Double Bed | King Size Fitted Mattress Protector | Anti Slip Bed Sheet | Beddy&#039;s Studio', '160000', '&lt;ul&gt;&lt;li&gt;Waterproof Mattress Cover For Double Bed | King Size Fitted Mattress Protector | Anti Slip Bed Sheet | Beddy&#039;s Studio&lt;/li&gt;&lt;li&gt;Waterproof Mattress Cover For Double Bed | King Size Fitted Mattress Protector | Anti Slip Bed Sheet | Beddy&#039;s Studio&lt;/li&gt;&lt;/ul&gt;', '1632555017-bed1.jpg', 1, '', 0, 1),
(48, '1632555130', 22, 42, 0, 'Caboki Hair Fibers DARK Brown 25g', '300', '&lt;ul&gt;&lt;li&gt;Caboki Hair Fibers DARK &lt;strong&gt;Brown &lt;/strong&gt;&lt;i&gt;25g&lt;/i&gt;&lt;/li&gt;&lt;li&gt;Caboki Hair Fibers DARK Brown 25g&lt;/li&gt;&lt;/ul&gt;', '1632555130-hair_care1.jpg', 56, '', 0, 1),
(49, '1632555194', 22, 42, 0, 'LIFEBUOY HERBAL SHAMPOO 375ml', '320', '&lt;ol&gt;&lt;li&gt;LIFEBUOY HERBAL SHAMPOO 375ml&lt;/li&gt;&lt;li&gt;LIFEBUOY HERBAL &lt;strong&gt;SHAMPOO &lt;/strong&gt;375ml&lt;/li&gt;&lt;li&gt;LIFEBUOY &lt;i&gt;HERBAL&amp;nbsp;&lt;/i&gt;&lt;/li&gt;&lt;/ol&gt;', '1632555194-hair_care2.jpg', 67, '', 0, 1),
(50, '1632555271', 22, 41, 0, 'Mega Discount, Impression of Lady Million by Paco Rabanne concentrated attar perfume Oil', '3000', '&lt;p&gt;Mega Discount, Impression of Lady Million by Paco Rabanne concentrated attar perfume OilMega Discount, Impression of Lady Million by Paco Rabanne concentrated attar perfume OilMega Discount, Impression of Lady Million by Paco Rabanne concentrated attar perfume Oil.&lt;/p&gt;', '1632555271-fragrances2.jpg', 26, '', 0, 1),
(51, '1632555327', 22, 41, 0, 'Pack of 6 - Body Sprays for Women Randomly Selected', '500', '&lt;ul&gt;&lt;li&gt;Pack of 6 - Body Sprays for Women Randomly Selected&lt;/li&gt;&lt;li&gt;Pack of 6 - Body Sprays for Women Randomly Selected&lt;/li&gt;&lt;li&gt;Pack of 6 - Body Sprays for Women Randomly Selected&lt;/li&gt;&lt;li&gt;Pack of 6 - Body Sprays for Women Randomly Selected&lt;/li&gt;&lt;/ul&gt;', '1632555327-fragrances1.jpg', 12, '', 0, 1),
(52, '1632555504', 22, 40, 0, 'Electric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - Blue', '6000', '&lt;ol&gt;&lt;li&gt;Electric Beard Straightener for Men &lt;strong&gt;Multifunctional &lt;/strong&gt;Ionic Beard Straightening Hair Style Electric Hot Comb - Blue&lt;/li&gt;&lt;li&gt;Electric Beard Straightener for &lt;i&gt;Men &lt;/i&gt;Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb&amp;nbsp;&lt;/li&gt;&lt;/ol&gt;', '1632555504-beauty2.jpg', 23, '', 0, 1),
(53, '1632555642', 22, 40, 0, 'Electric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - Blue', '500', '&lt;ul&gt;&lt;li&gt;Electric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - Blue&lt;/li&gt;&lt;li&gt;Electric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - Blue&lt;/li&gt;&lt;/ul&gt;', '1632555642-beauty1.jpg', 12, '', 0, 1),
(54, '1632559927', 26, 37, 0, 'Whiskas Cat Food 1+ Meaty Selection in Gravy Box(12 Mix Flavor Sachets)', '100', '&lt;p&gt;Whiskas Cat Food 1+ Meaty Selection in Gravy Box(12 Mix Flavor Sachets)Whiskas Cat Food 1+ Meaty Selection in Gravy Box(12 Mix Flavor Sachets)Whiskas Cat Food 1+ Meaty Selection in Gravy Box(12 Mix Flavor Sachets)Whiskas Cat Food 1+ Meaty Selection in Gravy Box(12 Mix Flavor Sachets)&lt;/p&gt;', '1632559927-cats.jpg', 12, '', 0, 1),
(55, '1632559975', 26, 37, 0, 'Friskies Pat&eacute; Mixed Grill Adult Wet Cat Food - 156gm', '500', '&lt;p&gt;Friskies Pat&eacute; Mixed Grill Adult Wet Cat Food - 156gmFriskies Pat&eacute; Mixed Grill Adult Wet Cat Food - 156gmFriskies Pat&eacute; Mixed Grill Adult Wet Cat Food - 156gmFriskies Pat&eacute; Mixed Grill Adult Wet Cat Food - 156gm&lt;/p&gt;', '1632559975-cats2.jpg', 12, '', 0, 1),
(56, '1632636351', 16, 36, 17, 'Electric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - Blue', '500', '&lt;p&gt;Electric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - BlueElectric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - BlueElectric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - BlueElectric Beard Straightener for Men Multifunctional Ionic Beard Straightening Hair Style Electric Hot Comb - Blue&lt;/p&gt;', '1632636351-beauty1.jpg', 12, '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `rating_id` int(50) NOT NULL,
  `product_id` int(50) NOT NULL,
  `product_rating` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `sub_cat_id` int(11) NOT NULL,
  `sub_cat_title` varchar(100) NOT NULL,
  `cat_parent` int(11) NOT NULL,
  `cat_products` int(11) NOT NULL DEFAULT 0,
  `show_in_menu` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`sub_cat_id`, `sub_cat_title`, `cat_parent`, `cat_products`, `show_in_menu`) VALUES
(18, 'Mircrowave ', 16, 0, 1),
(52, 'Laptop', 16, 0, 1),
(21, 'Smart Phones', 16, 0, 1),
(22, 'Tablets', 16, 0, 1),
(23, 'Desktops', 16, 0, 1),
(24, 'Gaming &amp; Drones', 16, 0, 1),
(25, 'T-shirts &amp; Tanks', 24, 0, 1),
(26, 'Shirts &amp; Polo', 24, 0, 1),
(27, 'Pants &amp; Jeans', 24, 0, 1),
(28, 'Shoes', 24, 0, 1),
(29, 'Muslim wear', 25, 0, 1),
(30, 'Shoes', 25, 0, 1),
(31, 'Girls&#039; Clothing', 25, 0, 1),
(32, 'Dresses &amp; Skirts', 25, 0, 1),
(34, 'Fresh Products', 26, 0, 1),
(35, 'Breakfast, choco &amp; snacks', 26, 0, 1),
(36, 'Dairy &amp; Chilled', 26, 0, 1),
(37, 'Cat', 26, 0, 1),
(38, 'Dog', 26, 0, 1),
(39, 'Bath &amp; Body', 22, 0, 1),
(40, 'Beauty Tools', 22, 0, 1),
(41, 'Fragrances', 22, 0, 1),
(42, 'Hair Care', 22, 0, 1),
(43, 'Bath', 21, 0, 1),
(44, 'Bedding', 21, 0, 1),
(45, 'Forniture', 21, 0, 1),
(46, 'Kitchen &amp; Dining', 21, 0, 1),
(47, 'Laundry &amp; Cleaning', 21, 0, 1),
(48, 'Exercise &amp; Fitness', 18, 0, 1),
(49, 'Supplements', 18, 0, 1),
(50, 'Team Sports', 18, 0, 1),
(51, 'Sports Accessories', 18, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `user_role` int(11) DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `f_name`, `l_name`, `username`, `password`, `mobile`, `user_role`) VALUES
(22, 'Asad', 'Ullah', 'asadb@gmail.com', '$2y$10$P/FMwa7.HSNUOBwHG.wQ9e8.2lHX1ESQMbnCAP7bMl6iQlIcCRQvC', '90939333', 1),
(24, 'Khawar', 'Saleem', 'khawar@gmail.com', '$2y$10$kAdWo7xzRrvWXsGKGsUFLeycTMMpMdR0T1izc2T9HNaK92UzDa17y', '90930493', 1);

-- --------------------------------------------------------

--
-- Table structure for table `whish_list`
--

CREATE TABLE `whish_list` (
  `wish_id` int(50) NOT NULL,
  `user_id` int(50) NOT NULL,
  `product_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `whish_list`
--

INSERT INTO `whish_list` (`wish_id`, `user_id`, `product_id`) VALUES
(5, 24, 28),
(8, 22, 24),
(9, 22, 20),
(10, 22, 46),
(11, 22, 47),
(12, 22, 49),
(13, 22, 40),
(14, 22, 29),
(15, 22, 41),
(16, 22, 22);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_cart`
--
ALTER TABLE `add_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`rating_id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`sub_cat_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `whish_list`
--
ALTER TABLE `whish_list`
  ADD PRIMARY KEY (`wish_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_cart`
--
ALTER TABLE `add_cart`
  MODIFY `cart_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `rating_id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `sub_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `whish_list`
--
ALTER TABLE `whish_list`
  MODIFY `wish_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
