
<?php include "./partials/header.php"; ?>


<div class="container-fluid px-md-5 py-5">
    <div class="row py-3">
        <div class="col-sm-5">
            <img src="./images/card1.jpg" class="single_product_image" alt="">
        </div>
        <div class="col-md-5 col-sm-7 content_cont py-3 d-flex flex-column justify-content-center">
            <h5>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur, aliquid?</h5>
            <p class="text-info mb-0" style="font-size: 1.1rem;">Rs. 200</p>
            <div class="ratings">
                Rating Stars here
            </div>
            <div>
                <a href="" class="btn btn_buy">Buy Now</a>
                <a href="" class="btn btn_cart">Add to Cart</a>
            </div>
            
        </div>
    </div>
</div>






<?php include "./partials/footer.php"; ?>