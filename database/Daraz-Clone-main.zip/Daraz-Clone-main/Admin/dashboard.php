<?php include "header.php"; ?>

<div class="container-fluid">
    <div class="row">
        <?php include "sidebar.php"; ?>

        <div class="col-md-9 items_container">
            <h2 class="ms-md-5 mt-4">Dashboard</h2>
            <hr class="ms-md-5">

            <div class="row items ms-md-5 mt-sm-1 mb-5 gy-sm-5 gy-3">
            <div class="col-sm-4 col-6">
                <div class="box">
                        <h2 class="counts">9</h2>
                        <h2 class="name_item">Products</h2>
                    </div>
                </div>
                <div class="col-sm-4 col-6">
                <div class="box">
                        <h2 class="counts">9</h2>
                        <h2 class="name_item">Products</h2>
                    </div>
                </div>
                <div class="col-sm-4 col-6">
                <div class="box">
                        <h2 class="counts">9</h2>
                        <h2 class="name_item">Products</h2>
                    </div>
                </div>
                <div class="col-sm-4 col-6">
                <div class="box">
                        <h2 class="counts">9</h2>
                        <h2 class="name_item">Products</h2>
                    </div>
                </div>
                <div class="col-sm-4 col-6">
                <div class="box">
                        <h2 class="counts">9</h2>
                        <h2 class="name_item">Products</h2>
                    </div>
                </div>
                <div class="col-sm-4 col-6">
                <div class="box">
                        <h2 class="counts">9</h2>
                        <h2 class="name_item">Products</h2>
                    </div>
                </div>
                <div class="col-sm-4 col-6">
                <div class="box">
                        <h2 class="counts">9</h2>
                        <h2 class="name_item">Products</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>