
        <div class="col-2 d-md-block d-none px-3 ofsidebar" style="box-sizing: content-box;">
        <ul>
            <a href="dashboard.php">
                <li>Dashboard</li>
            </a><a href="products.php">
                <li>products</li>
            </a><a href="categories.php">
                <li>categories</li>
            </a><a href="sub_categories.php">
                <li>sub-categories</li>
            </a><a href="brands.php">
                <li>Brands</li>
            </a><a href="orders.php">
                <li>orders</li>
            </a><a href="users.php">
                <li>users</li>
            </a><a href="settings.php">
                <li>settings</li>
            </a>
        </ul>
        </div>
